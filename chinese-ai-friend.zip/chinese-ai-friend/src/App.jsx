// ────────────────────────────────────────────────
// App 컴포넌트 (루트)
// 현재는 단일 페이지 구조이므로 HomePage 만 렌더링한다.
// 추후 페이지가 늘어나면 여기에서 라우팅을 추가할 수 있다.
// ────────────────────────────────────────────────

import HomePage from './pages/HomePage.jsx'

function App() {
  return <HomePage />
}

export default App
