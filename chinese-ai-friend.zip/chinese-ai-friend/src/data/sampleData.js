// ────────────────────────────────────────────────
// 샘플 학습 분석 데이터
//
// 이 프로젝트는 "교육용 학습 피드백"을 보여주는 것이 목적이므로,
// 자주 쓰는 예문에 대해 미리 정교하게 작성한 분석 결과를 담아둔다.
// 입력 문장이 아래 key 와 일치하면 이 분석 결과를 그대로 보여주고,
// 일치하지 않으면 analyzer.js 의 규칙 기반 분석이 동작한다.
//
// 데이터 구조(= 결과 카드 9개 항목)
//   natural        : 자연 번역
//   naturalPinyin  : 자연 번역 병음
//   literal        : 직역(어색한 표현)
//   literalNote    : 직역이 어색한 이유
//   grammar        : 핵심 문법 설명
//   errors[]       : { type, desc, isGood } 학습자 오류 피드백
//   situations[]   : { tag, cn, py } 상황별 표현 차이
//   conversation[] : { cn, py, ko } 실제 회화 표현
//   culture        : 문화적 맥락 설명
//   hsk            : { level, label, desc } HSK 난이도
// ────────────────────────────────────────────────

export const SAMPLE_DATA = {
  // 한국어식 직역 오류를 보여주는 대표 예문
  '밥 먹었어?': {
    natural: '你吃饭了吗？',
    naturalPinyin: 'Nǐ chī fàn le ma?',
    literal: '饭吃了吗？',
    literalNote:
      '한국어 "밥 먹었어?"를 그대로 옮기면 주어(你)가 빠져 어색합니다. 중국어는 안부 인사로 이 표현을 자주 쓰며, 주어를 넣는 것이 자연스럽습니다.',
    grammar:
      '"了"는 동작의 완료를 나타내고, 문장 끝 "吗"는 의문을 만듭니다. "동사 + 了 + 吗?" 구조로 "~했니?"를 표현합니다.',
    errors: [
      {
        type: '한국어식 어순',
        desc: '한국어는 주어를 자주 생략하지만, 중국어 안부 인사에서는 "你"를 넣어야 자연스럽습니다.',
        isGood: false,
      },
      {
        type: '문화적 맥락',
        desc: '"밥 먹었어?"는 중국에서 실제 식사 여부보다 "잘 지내?"에 가까운 인사로 쓰입니다.',
        isGood: false,
      },
    ],
    situations: [
      { tag: '친구 사이', cn: '吃了吗？', py: 'Chī le ma?' },
      { tag: '공식적', cn: '您用过餐了吗？', py: 'Nín yòng guò cān le ma?' },
      { tag: 'SNS', cn: '干饭了没？', py: 'Gàn fàn le méi?' },
    ],
    conversation: [
      { cn: '吃了吗您？', py: 'Chī le ma nín?', ko: '식사하셨어요? (정겨운 안부 인사)' },
      { cn: '还没呢，你呢？', py: 'Hái méi ne, nǐ ne?', ko: '아직요, 당신은요?' },
    ],
    culture:
      '중국에서 "你吃饭了吗？"는 글자 그대로의 질문이라기보다 친근한 안부 인사입니다. 한국의 "잘 지내?"와 비슷한 역할을 하므로, 정말 밥 먹었는지 답하지 않아도 됩니다.',
    hsk: { level: 1, label: 'HSK 1급', desc: '가장 기초적인 일상 인사 표현입니다.' },
    recommend: [
      { cn: '你吃了吗？', py: 'Nǐ chī le ma?' },
      { cn: '吃饭了没？', py: 'Chī fàn le méi?' },
    ],
  },

  '주말에 같이 영화 볼래?': {
    natural: '周末要不要一起看电影？',
    naturalPinyin: 'Zhōumò yào bú yào yìqǐ kàn diànyǐng?',
    literal: '周末一起电影看吗？',
    literalNote:
      '"영화 보다"를 "电影看"으로 옮기면 어순이 틀립니다. 중국어는 "동사(看) + 목적어(电影)" 순서이므로 "看电影"이 맞습니다.',
    grammar:
      '"要不要"는 "~할래?"라는 권유 표현입니다. "一起"는 "함께"라는 뜻으로 동사 앞에 옵니다. 어순은 "시간 + 要不要 + 一起 + 동사 + 목적어"입니다.',
    errors: [
      {
        type: '한국어식 어순',
        desc: '"电影看"처럼 목적어를 동사 앞에 두면 안 됩니다. 중국어는 "看电影" (동사+목적어) 순서입니다.',
        isGood: false,
      },
    ],
    situations: [
      { tag: '친구 사이', cn: '周末一起看电影呗？', py: 'Zhōumò yìqǐ kàn diànyǐng bei?' },
      { tag: '공식적', cn: '周末方便一起观影吗？', py: 'Zhōumò fāngbiàn yìqǐ guānyǐng ma?' },
      { tag: 'SNS', cn: '周末约个电影？', py: 'Zhōumò yuē ge diànyǐng?' },
    ],
    conversation: [
      { cn: '周末有空吗？一起看电影呗。', py: 'Zhōumò yǒu kòng ma? Yìqǐ kàn diànyǐng bei.', ko: '주말에 시간 있어? 같이 영화 보자.' },
      { cn: '好啊，看什么？', py: 'Hǎo a, kàn shénme?', ko: '좋아, 뭐 볼래?' },
    ],
    culture:
      '중국 젊은이들은 약속을 잡을 때 "约"(약속을 잡다)라는 동사를 자주 씁니다. "约个电影"처럼 명사 앞에 "约"을 붙이면 캐주얼하고 자연스럽게 들립니다.',
    hsk: { level: 2, label: 'HSK 2급', desc: '권유와 일상 약속에 쓰는 기초 표현입니다.' },
    recommend: [
      { cn: '周末一起去看电影吧！', py: 'Zhōumò yìqǐ qù kàn diànyǐng ba!' },
    ],
  },

  '我吃饭了': {
    natural: '나 밥 먹었어.',
    naturalPinyin: 'Wǒ chī fàn le.',
    literal: '나는 밥을 먹었다.',
    literalNote:
      '문법적으로 틀리진 않지만, 일상 대화에서는 조사를 줄여 "나 밥 먹었어"가 더 자연스럽습니다.',
    grammar:
      '"了"는 동작 완료를 나타냅니다. "我(나) + 吃(먹다) + 饭(밥) + 了(완료)" 구조로, 한국어로는 과거형 "먹었어"가 됩니다.',
    errors: [
      {
        type: '잘 쓴 표현',
        desc: '주어 + 동사 + 목적어 + 了 의 어순이 정확합니다. 기초 문장을 잘 구성했어요!',
        isGood: true,
      },
    ],
    situations: [
      { tag: '친구 사이', cn: '吃过啦！', py: 'Chī guò la!' },
      { tag: '공식적', cn: '我已经用过餐了。', py: 'Wǒ yǐjīng yòng guò cān le.' },
      { tag: 'SNS', cn: '干完饭了～', py: 'Gàn wán fàn le~' },
    ],
    conversation: [
      { cn: '我吃过了，你吃了吗？', py: 'Wǒ chī guò le, nǐ chī le ma?', ko: '나 먹었어, 너는 먹었어?' },
    ],
    culture:
      '"了"의 위치에 따라 의미가 달라집니다. "吃了饭"과 "吃饭了"는 모두 가능하지만, 문장 끝의 "了"는 "이제 막 ~했다"는 변화의 느낌을 줍니다.',
    hsk: { level: 1, label: 'HSK 1급', desc: '완료를 나타내는 가장 기본적인 문장입니다.' },
    recommend: [
      { cn: '나 방금 밥 먹었어.', py: '(我刚吃完饭。 Wǒ gāng chī wán fàn.)' },
    ],
  },
}
