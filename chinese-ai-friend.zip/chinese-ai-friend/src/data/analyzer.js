// ────────────────────────────────────────────────
// 학습 분석 엔진 (analyzer.js)
//
// 1) 입력 문장이 sampleData 에 있으면 → 미리 작성한 정교한 분석 반환
// 2) 없으면 → 규칙 기반(rule-based) 오류 탐지로 학습 피드백 생성
//
// 규칙 기반 분석은 "한국어식 중국어 오류"를 탐지하는 데 초점을 둔다.
// (직역 위험 패턴, 어순 문제, 부자연스러운 표현 등)
//
// ※ 실제 생성형 AI 연동을 원할 경우, 아래 callRealAI() 함수처럼
//   서버리스 함수(/api) 를 통해 호출하도록 확장할 수 있다.
//   (API 키를 프론트엔드에 직접 두면 안 되므로 백엔드가 필요하다.)
// ────────────────────────────────────────────────

import { SAMPLE_DATA } from './sampleData.js'
import { getSituation } from './situations.js'

// 입력이 중국어인지(한자 포함) 한국어인지 간단 판별
function detectLanguage(text) {
  const hasHanzi = /[\u4e00-\u9fff]/.test(text)
  const hasHangul = /[\uac00-\ud7a3]/.test(text)
  if (hasHangul) return 'ko'
  if (hasHanzi) return 'cn'
  return 'ko'
}

// 한국어식 중국어 오류를 탐지하는 간단한 규칙 모음
// (실제 학습자 오류 유형 분석 결과를 단순화하여 반영)
const KO_STYLE_RULES = [
  {
    test: (t) => /보다|먹다|마시다|하다/.test(t) && /을|를/.test(t),
    type: '직역 위험',
    desc: '한국어 "목적어 + 동사" 어순을 그대로 옮기면 어색합니다. 중국어는 "동사 + 목적어" 순서입니다. (예: 看电影)',
  },
  {
    test: (t) => /너무|진짜|완전/.test(t),
    type: '부자연스러운 강조',
    desc: '"너무/진짜"를 매번 "很"으로 옮기면 단조롭습니다. 상황에 따라 "太…了", "非常", "特别" 등으로 다양하게 표현하세요.',
  },
  {
    test: (t) => /(요|습니다|합니다)$/.test(t.trim()),
    type: '존댓말 처리',
    desc: '한국어 존댓말은 중국어에서 어미 변화가 아니라 "您", "请", 정중한 어휘 선택으로 표현됩니다.',
  },
]

// 규칙 기반 분석 결과 생성
function ruleBasedAnalysis(text, situationId) {
  const lang = detectLanguage(text)
  const situ = getSituation(situationId)

  // 탐지된 오류 모으기
  const errors = []
  if (lang === 'ko') {
    KO_STYLE_RULES.forEach((rule) => {
      if (rule.test(text)) {
        errors.push({ type: rule.type, desc: rule.desc, isGood: false })
      }
    })
  }
  // 오류가 하나도 없으면 격려 메시지
  if (errors.length === 0) {
    errors.push({
      type: '잘 쓴 표현',
      desc: '눈에 띄는 한국어식 오류가 보이지 않아요. 아래 상황별 표현으로 더 자연스럽게 다듬어 보세요!',
      isGood: true,
    })
  }

  return {
    natural:
      lang === 'ko'
        ? '（예시 번역）这句话可以这样表达。'
        : '（예시 번역）이 문장은 이렇게 표현할 수 있어요.',
    naturalPinyin: lang === 'ko' ? 'Zhè jù huà kěyǐ zhèyàng biǎodá.' : '',
    literal:
      lang === 'ko'
        ? '직역하면 어순이나 조사가 어색해질 수 있습니다.'
        : '글자 그대로 옮기면 한국어 어순과 맞지 않을 수 있습니다.',
    literalNote:
      '직역은 단어를 1:1로 바꾸기 때문에, 문장의 맥락과 자연스러움을 놓치기 쉽습니다.',
    grammar:
      `선택한 상황은 "${situ.label}"(${situ.tone})입니다. 같은 뜻이라도 상황에 따라 어휘와 말투를 바꿔야 합니다. ` +
      '중국어 기본 어순은 "주어 + 동사 + 목적어"이며, 시간·장소 표현은 동사 앞에 옵니다.',
    errors,
    situations: [
      { tag: '친구 사이', cn: '（편한 말투 표현）', py: '' },
      { tag: '공식적', cn: '（정중한 표현, 您/请 사용）', py: '' },
      { tag: 'SNS', cn: '（짧고 트렌디한 인터넷 말투）', py: '' },
    ],
    conversation: [
      {
        cn: '这个用中文怎么说？',
        py: 'Zhège yòng zhōngwén zěnme shuō?',
        ko: '이거 중국어로 어떻게 말해요? (모를 때 쓰는 만능 표현)',
      },
    ],
    culture:
      '중국어는 같은 의미라도 관계와 상황에 따라 표현이 크게 달라집니다. 친구에게 쓰는 말투와 공식 자리에서 쓰는 말투를 구분하는 것이 자연스러운 회화의 핵심입니다.',
    hsk: { level: 2, label: 'HSK 2급', desc: '문장 구성에 따라 난이도가 달라질 수 있습니다.' },
    recommend: [
      { cn: '请帮我看看这句话对不对。', py: 'Qǐng bāng wǒ kànkan zhè jù huà duì bú duì.' },
    ],
  }
}

// 외부에 노출하는 메인 분석 함수
// 약간의 지연(setTimeout)을 주어 "분석 중" 로딩 UX 를 자연스럽게 만든다.
export function analyzeSentence(text, situationId) {
  return new Promise((resolve) => {
    setTimeout(() => {
      const key = text.trim()
      if (SAMPLE_DATA[key]) {
        // 미리 작성한 정교한 분석이 있으면 그것을 사용
        resolve({ ...SAMPLE_DATA[key], recommend: SAMPLE_DATA[key].recommend || [] })
      } else {
        // 없으면 규칙 기반 분석
        resolve(ruleBasedAnalysis(text, situationId))
      }
    }, 600)
  })
}

// ────────────────────────────────────────────────
// (선택) 실제 생성형 AI 연동 예시 - 서버리스 백엔드 필요
// Vercel 에 /api/analyze.js 같은 서버리스 함수를 두고,
// 그 함수 안에서 API 키를 환경변수로 안전하게 사용한다.
// ────────────────────────────────────────────────
// export async function callRealAI(text, situationId) {
//   const res = await fetch('/api/analyze', {
//     method: 'POST',
//     headers: { 'Content-Type': 'application/json' },
//     body: JSON.stringify({ text, situationId }),
//   })
//   return await res.json()
// }
