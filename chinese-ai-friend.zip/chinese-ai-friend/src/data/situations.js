// ────────────────────────────────────────────────
// 상황(맥락) 선택 옵션 데이터
// 맥락 기반 학습이 이 프로젝트의 핵심이므로,
// 상황별로 말투와 표현이 어떻게 달라지는지를 보여주기 위한 기준값이다.
// ────────────────────────────────────────────────

export const SITUATIONS = [
  { id: 'friend', label: '친구와 대화', emoji: '🧑‍🤝‍🧑', tone: '편하고 친근한 반말체' },
  { id: 'school', label: '학교 발표', emoji: '🎓', tone: '정중하고 또렷한 발표체' },
  { id: 'travel', label: '여행', emoji: '🧳', tone: '간단하고 실용적인 여행 회화체' },
  { id: 'sns',    label: 'SNS',      emoji: '💬', tone: '짧고 트렌디한 인터넷 말투' },
  { id: 'formal', label: '공식 표현', emoji: '📄', tone: '예의 바르고 격식 있는 표현' },
]

// id로 상황 객체를 찾는 헬퍼
export function getSituation(id) {
  return SITUATIONS.find((s) => s.id === id) || SITUATIONS[0]
}
