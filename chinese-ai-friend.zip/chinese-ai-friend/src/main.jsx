// ────────────────────────────────────────────────
// main.jsx
// React 앱의 진입점. App 을 root 에 마운트하고
// 전역 스타일과 컴포넌트 스타일을 불러온다.
// ────────────────────────────────────────────────

import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import './styles/global.css'
import './styles/components.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
)
