// ────────────────────────────────────────────────
// ResultView 컴포넌트
// 분석 결과(data)를 받아 9개 학습 항목을 카드로 출력한다.
//   1. 자연 번역 + 병음
//   2. 직역
//   3. 핵심 문법
//   4. 학습자 오류 피드백
//   5. 상황별 표현 차이
//   6. 실제 회화 표현
//   7. 문화적 맥락
//   8. HSK 난이도
//   9. 자연스러운 현지 표현 추천
//
// props:
//   data    : 분석 결과 객체 (null 이면 빈 상태)
//   loading : 분석 중 여부
// ────────────────────────────────────────────────

import ResultCard from './ResultCard.jsx'

function ResultView({ data, loading }) {
  // 분석 중 로딩 표시
  if (loading) {
    return (
      <div className="results-area">
        <div className="loading-state">
          AI 친구가 문장을 살펴보고 있어요
          <div className="loading-dots">
            <span className="loading-dot" />
            <span className="loading-dot" />
            <span className="loading-dot" />
          </div>
        </div>
      </div>
    )
  }

  // 아직 분석 전: 빈 상태
  if (!data) {
    return (
      <div className="results-area">
        <div className="empty-state">
          <span className="empty-state-icon">🍵</span>
          문장을 입력하고 <strong>학습 분석 받기</strong>를 눌러보세요.
          <br />
          AI 친구가 번역과 함께 학습 피드백을 정리해 드려요.
        </div>
      </div>
    )
  }

  // HSK 게이지 너비 계산 (1~6급 → 0~100%)
  const hskLevel = Math.min(6, Math.max(1, data.hsk?.level || 1))
  const hskWidth = ((hskLevel / 6) * 100).toFixed(0) + '%'

  return (
    <div className="results-area">
      {/* 1. 자연 번역 */}
      <ResultCard icon="✓" iconBg="#dceee5" title="자연스러운 번역">
        <div className="translation-main">{data.natural}</div>
        {data.naturalPinyin && <div className="translation-pinyin">{data.naturalPinyin}</div>}
      </ResultCard>

      {/* 2. 직역 */}
      <ResultCard icon="↔" iconBg="var(--color-beige)" title="직역 (이렇게 말하면 어색해요)">
        <div className="literal-text">{data.literal}</div>
        <div className="literal-note">💡 {data.literalNote}</div>
      </ResultCard>

      {/* 3. 핵심 문법 */}
      <ResultCard icon="文" iconBg="#e6e0f0" title="핵심 문법 설명">
        <div className="text-block">
          <p>{data.grammar}</p>
        </div>
      </ResultCard>

      {/* 4. 오류 피드백 */}
      {data.errors && data.errors.length > 0 && (
        <ResultCard icon="!" iconBg="var(--color-red-soft)" title="학습자 오류 피드백">
          {data.errors.map((err, i) => (
            <div
              key={i}
              className={'error-item' + (err.isGood ? ' error-item--good' : '')}
            >
              <div className="error-type">
                {err.isGood ? '👍 ' : ''}
                {err.type}
              </div>
              <div className="error-desc">{err.desc}</div>
            </div>
          ))}
        </ResultCard>
      )}

      {/* 5. 상황별 표현 차이 */}
      {data.situations && data.situations.length > 0 && (
        <ResultCard icon="◑" iconBg="var(--color-blue-soft)" title="상황별 표현 차이">
          <div className="situation-compare">
            {data.situations.map((s, i) => (
              <div key={i} className="situation-compare-row">
                <span className="situation-compare-tag">{s.tag}</span>
                <span className="situation-compare-expr">
                  <span className="cn">{s.cn}</span>
                  {s.py && <span className="py"> · {s.py}</span>}
                </span>
              </div>
            ))}
          </div>
        </ResultCard>
      )}

      {/* 6. 실제 회화 표현 */}
      {data.conversation && data.conversation.length > 0 && (
        <ResultCard icon="话" iconBg="#f6e3d6" title="실제 중국 회화 표현">
          {data.conversation.map((c, i) => (
            <div key={i} className="conv-bubble">
              <span className="cn">{c.cn}</span> {c.py && <span className="py">{c.py}</span>}
              <span className="ko">{c.ko}</span>
            </div>
          ))}
        </ResultCard>
      )}

      {/* 7. 문화적 맥락 */}
      <ResultCard icon="化" iconBg="#eee6da" title="문화적 맥락 설명">
        <div className="text-block">
          <p>{data.culture}</p>
        </div>
      </ResultCard>

      {/* 8. HSK 난이도 */}
      {data.hsk && (
        <ResultCard icon="级" iconBg="#f6e3d6" title="HSK 난이도">
          <div className="hsk-wrap">
            <span className="hsk-badge">{data.hsk.label || 'HSK ' + hskLevel + '급'}</span>
            <div className="hsk-bar">
              <div className="hsk-fill" style={{ width: hskWidth }} />
            </div>
            <div className="hsk-desc">{data.hsk.desc}</div>
          </div>
        </ResultCard>
      )}

      {/* 9. 추천 표현 */}
      {data.recommend && data.recommend.length > 0 && (
        <ResultCard icon="☆" iconBg="#dceee5" title="자연스러운 현지 표현 추천">
          <div className="reco-list">
            {data.recommend.map((r, i) => (
              <div key={i} className="reco-item">
                <span className="star">★</span>
                <span>
                  <span className="cn">{r.cn}</span>
                  {r.py && <span className="py">{r.py}</span>}
                </span>
              </div>
            ))}
          </div>
        </ResultCard>
      )}
    </div>
  )
}

export default ResultView
