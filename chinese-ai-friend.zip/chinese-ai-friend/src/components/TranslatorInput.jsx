// ────────────────────────────────────────────────
// TranslatorInput 컴포넌트
// 번역 방향 토글 + 입력창 + 상황 선택 + 제출 버튼을 묶은 입력 카드
// props:
//   text, setText        : 입력 문장 상태
//   direction, setDirection : 번역 방향 ('ko2cn' | 'cn2ko')
//   situation, setSituation : 선택된 상황 id
//   onSubmit             : 제출 핸들러
//   loading              : 분석 중 여부
// ────────────────────────────────────────────────

import SituationSelector from './SituationSelector.jsx'

function TranslatorInput({
  text,
  setText,
  direction,
  setDirection,
  situation,
  setSituation,
  onSubmit,
  loading,
}) {
  // 방향에 따라 placeholder 문구를 다르게 보여준다
  const placeholder =
    direction === 'ko2cn'
      ? '예) 밥 먹었어? / 주말에 같이 영화 볼래? / 만나서 반가워요'
      : '예) 我吃饭了 / 你周末有空吗？/ 很高兴认识你'

  // Ctrl/Cmd + Enter 로 제출
  function handleKeyDown(e) {
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      onSubmit()
    }
  }

  return (
    <div className="input-card">
      {/* 번역 방향 토글 */}
      <div className="direction-row">
        <button
          type="button"
          className={'direction-btn' + (direction === 'ko2cn' ? ' direction-btn--active' : '')}
          onClick={() => setDirection('ko2cn')}
        >
          한국어 → 중국어
        </button>
        <button
          type="button"
          className={'direction-btn' + (direction === 'cn2ko' ? ' direction-btn--active' : '')}
          onClick={() => setDirection('cn2ko')}
        >
          중국어 → 한국어
        </button>
      </div>

      {/* 입력창 */}
      <div className="field-label">📝 학습할 문장을 입력해 보세요</div>
      <textarea
        className="input-textarea"
        value={text}
        placeholder={placeholder}
        onChange={(e) => setText(e.target.value)}
        onKeyDown={handleKeyDown}
      />

      {/* 상황 선택 */}
      <SituationSelector selected={situation} onSelect={setSituation} />

      {/* 제출 버튼 */}
      <button className="submit-btn" onClick={onSubmit} disabled={loading}>
        {loading ? '분석 중...' : '학습 분석 받기'}
      </button>
      <p className="input-hint">
        결과는 자연 번역 · 직역 · 병음 · 문법 · 오류 피드백 · 상황별 표현 · 회화 · 문화 · HSK
        난이도로 정리됩니다
      </p>
    </div>
  )
}

export default TranslatorInput
