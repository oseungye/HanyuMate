// ────────────────────────────────────────────────
// Header 컴포넌트
// 로고 + 소개 문구 + 프로젝트 성격 안내
// ────────────────────────────────────────────────

function Header() {
  return (
    <header className="app-header">
      <div className="header-logo">
        <span className="header-logo-mark">朋</span>
        <span>나만의 중국어 AI 친구</span>
      </div>
      <p className="header-tagline">
        단순 번역이 아니라, <strong>왜 그렇게 말하는지</strong>까지 알려주는 중국어 학습 도우미
      </p>
      <span className="header-subnote">
        중국어 학습자의 오류 유형 분석 · 맥락 기반 언어 학습 탐구 프로젝트
      </span>
    </header>
  )
}

export default Header
