// ────────────────────────────────────────────────
// SituationSelector 컴포넌트
// 상황(맥락) 선택 버튼 그룹
// props:
//   selected   : 현재 선택된 상황 id
//   onSelect   : 상황 선택 시 호출되는 콜백
// ────────────────────────────────────────────────

import { SITUATIONS } from '../data/situations.js'

function SituationSelector({ selected, onSelect }) {
  return (
    <div>
      <div className="situation-label">💬 어떤 상황에서 쓸 말인가요?</div>
      <div className="situation-grid">
        {SITUATIONS.map((situ) => (
          <button
            key={situ.id}
            type="button"
            className={
              'situation-btn' + (selected === situ.id ? ' situation-btn--active' : '')
            }
            onClick={() => onSelect(situ.id)}
          >
            {situ.emoji} {situ.label}
          </button>
        ))}
      </div>
    </div>
  )
}

export default SituationSelector
