// ────────────────────────────────────────────────
// ResultCard 컴포넌트
// 모든 결과 항목을 감싸는 공통 카드 (제목 + 아이콘 + 내용)
// props:
//   icon     : 카드 아이콘 (이모지/한자)
//   iconBg   : 아이콘 배경색
//   title    : 카드 제목
//   children : 카드 본문 내용
// ────────────────────────────────────────────────

function ResultCard({ icon, iconBg, title, children }) {
  return (
    <div className="result-card">
      <div className="result-card-head">
        <div className="result-card-icon" style={{ background: iconBg }}>
          {icon}
        </div>
        <div className="result-card-title">{title}</div>
      </div>
      <div className="result-card-body">{children}</div>
    </div>
  )
}

export default ResultCard
