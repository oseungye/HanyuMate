// ────────────────────────────────────────────────
// HomePage 페이지 컴포넌트
// 앱의 메인 화면. 입력/상황/방향 상태를 관리하고,
// 분석 요청을 보내 결과를 ResultView 로 전달한다.
// ────────────────────────────────────────────────

import { useState } from 'react'
import Header from '../components/Header.jsx'
import TranslatorInput from '../components/TranslatorInput.jsx'
import ResultView from '../components/ResultView.jsx'
import Footer from '../components/Footer.jsx'
import { analyzeSentence } from '../data/analyzer.js'

function HomePage() {
  // ── 상태 정의 ──
  const [text, setText] = useState('') // 입력 문장
  const [direction, setDirection] = useState('ko2cn') // 번역 방향
  const [situation, setSituation] = useState('friend') // 선택된 상황
  const [result, setResult] = useState(null) // 분석 결과
  const [loading, setLoading] = useState(false) // 분석 중 여부

  // ── 분석 요청 핸들러 ──
  async function handleSubmit() {
    const trimmed = text.trim()
    if (!trimmed) return // 빈 입력 무시

    setLoading(true)
    setResult(null)
    try {
      const data = await analyzeSentence(trimmed, situation)
      setResult(data)
    } catch (err) {
      console.error(err)
      // 에러 시에도 빈 상태로 복귀 (간단 처리)
      setResult(null)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="app-container">
      <Header />
      <TranslatorInput
        text={text}
        setText={setText}
        direction={direction}
        setDirection={setDirection}
        situation={situation}
        setSituation={setSituation}
        onSubmit={handleSubmit}
        loading={loading}
      />
      <ResultView data={result} loading={loading} />
      <Footer />
    </div>
  )
}

export default HomePage
